package adham.com.islami

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity() {
}
